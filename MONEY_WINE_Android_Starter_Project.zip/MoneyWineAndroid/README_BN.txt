MONEY WINE Android Native Starter Project
=========================================

এটি একটি native Android Studio project-এর starter/demo source code।
এটি এখনও installable APK নয় এবং এখানে real login, server/database, ads, UPI বা bank payment যুক্ত নেই।
Dashboard, Tasks, Games, Profile এবং demo wallet screen আছে।

কীভাবে APK build করবেন:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. Android Studio > Open থেকে এই ফোল্ডারটি খুলুন।
3. Gradle sync শেষ হতে দিন এবং Android SDK Platform 35 ইনস্টল করুন।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
5. APK তৈরি হলে Android Studio-তে দেখানো location থেকে ফোনে পাঠিয়ে install করুন।

শুধু HTML বা এই project ফাইল খুললে Android app install হবে না। APK build করতে Android Studio ও Android SDK লাগবে।

পরবর্তী production কাজ:
- Secure backend/API ও database
- Google/Facebook/phone OTP authentication
- User/admin roles, server-side reward ledger, fraud protection
- Ad network integration ও privacy consent
- Payment provider integration এবং প্রযোজ্য আইন/নীতির review
- Signed release APK/AAB এবং Play Console publishing

সতর্কতা: Demo balance fictional. এই project কোনো বাস্তব deposit/withdrawal বা cash-prize game চালায় না।
