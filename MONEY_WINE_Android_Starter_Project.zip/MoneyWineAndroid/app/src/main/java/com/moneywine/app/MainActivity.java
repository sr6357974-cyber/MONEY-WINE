package com.moneywine.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    final int BG=Color.rgb(9,11,20), PANEL=Color.rgb(18,23,40), PURPLE=Color.rgb(139,92,246);
    final int MUTED=Color.rgb(155,167,196), GREEN=Color.rgb(49,208,170), WHITE=Color.rgb(246,247,255);
    LinearLayout root, body;
    double balance=120.0, earned=20.0;
    TextView balanceView, earnedView, pageTitle;
    int claimed=1;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        showDashboard();
    }
    GradientDrawable bg(int color, int radius, int stroke) {
        GradientDrawable d=new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        if(stroke!=0)d.setStroke(1,stroke);
        return d;
    }
    TextView text(String s,int size,int color,boolean bold) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    LinearLayout column() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    LinearLayout row() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    void pad(View v,int a) { v.setPadding(a,a,a,a); }
    TextView button(String label, Runnable action) {
        TextView b=text(label,14,WHITE,true); b.setGravity(Gravity.CENTER); b.setPadding(15,12,15,12);
        b.setBackground(bg(PURPLE,28,0)); b.setOnClickListener(v->action.run()); return b;
    }
    void base(String title) {
        root=column(); root.setBackgroundColor(BG); root.setPadding(16,16,16,12);
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout shell=column();
        LinearLayout header=row();
        TextView logo=text("MW",16,WHITE,true); logo.setGravity(Gravity.CENTER); logo.setBackground(bg(PURPLE,18,0)); 
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(46,46); lp.rightMargin=10; header.addView(logo,lp);
        LinearLayout brand=column(); brand.addView(text("MONEY WINE",19,WHITE,true)); brand.addView(text("PLAY  •  TASKS  •  REWARDS",9,MUTED,true));
        header.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView demo=text("DEMO",11,0xFFD7C8FF,true); demo.setPadding(10,8,10,8); demo.setBackground(bg(0xFF211B3A,30,0xFF5A4B87)); header.addView(demo);
        shell.addView(header); 
        pageTitle=text(title,27,WHITE,true); LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.topMargin=22;tp.bottomMargin=6;shell.addView(pageTitle,tp);
        shell.addView(text("Your little steps add up. Explore today's activities.",13,MUTED,false));
        body=column(); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.topMargin=18;shell.addView(body,bp);
        LinearLayout nav=row(); nav.setPadding(0,12,0,0);
        String[][] items={{"Home","home"},{"Tasks","tasks"},{"Games","games"},{"Wallet","wallet"},{"Profile","profile"}};
        for(String[] item:items){ TextView n=text(item[0],12,0xFFD7C8FF,true); n.setGravity(Gravity.CENTER); n.setPadding(9,12,9,12); n.setBackground(bg(0xFF211B3A,18,0)); LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,-2,1);np.setMargins(2,0,2,0);nav.addView(n,np);n.setOnClickListener(v->{switch(item[1]){case "home":showDashboard();break;case "tasks":showTasks();break;case "games":showGames();break;case "wallet":showWallet();break;case "profile":showProfile();break;}});}
        shell.addView(nav);
        scroll.addView(shell); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        root.addView(text("Prototype only • No real payments or accounts",10,MUTED,false));
        setContentView(root);
    }
    void card(LinearLayout parent, View child) {
        LinearLayout wrap=column(); wrap.setPadding(15,15,15,15); wrap.setBackground(bg(PANEL,22,0xFF28314A));
        wrap.addView(child); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=12;parent.addView(wrap,p);
    }
    void gap(LinearLayout parent,int h){View v=new View(this);parent.addView(v,new LinearLayout.LayoutParams(1,h));}
    void showDashboard() {
        base("Hey, welcome 👋");
        LinearLayout wallet=column();wallet.addView(text("DEMO WALLET BALANCE",11,0xFFC1B4E8,true));
        balanceView=text(fmt(balance),34,WHITE,true);wallet.addView(balanceView);wallet.addView(text("Sample balance — not real money",12,MUTED,false));gap(wallet,12);
        LinearLayout actions=row();actions.addView(button("Deposit demo",()->showWallet()));TextView space=text("  ",12,WHITE,false);actions.addView(space);actions.addView(button("Withdraw demo",()->showWallet()));wallet.addView(actions);card(body,wallet);
        LinearLayout stats=row();stats.addView(stat("🎁",fmt(earned),"Demo rewards"));stats.addView(stat("🎯",claimed+"/4","Tasks today"));card(body,stats);
        body.addView(text("TODAY'S TASKS",17,WHITE,true));gap(body,10);
        task("🎁","Daily check-in","Claim daily demo bonus","+₹5",true,()->Toast.makeText(this,"Already claimed in demo",Toast.LENGTH_SHORT).show());
        task("❓","Quick quiz","Try a sample question","+₹10",false,()->claim("Quick quiz",10));
        task("📺","Ad placement","Preview sponsored slot","+₹2",false,()->claim("Ad placement",2));
        task("👥","Invite a friend","Preview referral flow","+₹3",false,()->claim("Invite a friend",3));
        body.addView(text("FEATURED GAMES",17,WHITE,true));gap(body,8);
        task("🧩","Brain Puzzle","Free casual game","PLAY",false,()->showGames());
        task("❓","Quick Quiz","Sample quiz","PLAY",false,()->showGames());
        notice("Demo only: balances and rewards are fictional. No real deposits, payouts, or login are connected.");
    }
    View stat(String icon,String value,String label) {
        LinearLayout l=column();l.addView(text(icon+"  "+value,18,WHITE,true));l.addView(text(label,11,MUTED,false));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.setMargins(0,0,8,0);l.setLayoutParams(p);return l;
    }
    void task(String icon,String name,String desc,String reward,boolean done,Runnable run) {
        LinearLayout r=row(); TextView ic=text(icon,22,WHITE,true);ic.setGravity(Gravity.CENTER);ic.setBackground(bg(0xFF282142,18,0));LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(45,45);ip.rightMargin=10;r.addView(ic,ip);
        LinearLayout info=column();info.addView(text(name,14,WHITE,true));info.addView(text(desc,11,MUTED,false));r.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        TextView b=text(reward,12,GREEN,true);b.setGravity(Gravity.CENTER);b.setPadding(8,10,8,10);b.setOnClickListener(v->run.run());r.addView(b);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=9;
        LinearLayout wrap=column();wrap.setPadding(11,10,11,10);wrap.setBackground(bg(PANEL,16,0xFF28314A));wrap.addView(r);body.addView(wrap,p);
    }
    void showTasks(){base("Daily Tasks 🎯");task("🎁","Daily check-in","Claim daily demo bonus","+₹5",true,()->{});task("❓","Quick quiz","Try a sample question","+₹10",false,()->claim("Quick quiz",10));task("📺","Ad placement","Preview sponsored slot","+₹2",false,()->claim("Ad placement",2));task("👥","Invite a friend","Preview referral flow","+₹3",false,()->claim("Invite a friend",3));notice("Rewards in this prototype are sample credits, not cash.");}
    void showGames(){base("Free Games 🎮");task("🧩","Brain Puzzle","Puzzle game placeholder","OPEN",false,()->Toast.makeText(this,"Game can be added in a later version.",Toast.LENGTH_SHORT).show());task("❓","Quick Quiz","Quiz placeholder","OPEN",false,()->Toast.makeText(this,"Quiz can be added in a later version.",Toast.LENGTH_SHORT).show());task("🟣","Tap Challenge","Casual game placeholder","OPEN",false,()->Toast.makeText(this,"Game can be added in a later version.",Toast.LENGTH_SHORT).show());task("🧠","Memory Match","Memory game placeholder","OPEN",false,()->Toast.makeText(this,"Game can be added in a later version.",Toast.LENGTH_SHORT).show());notice("No paid-entry or cash-prize gameplay is enabled.");}
    void showWallet(){base("My Wallet 💳");LinearLayout w=column();w.addView(text("AVAILABLE DEMO BALANCE",11,0xFFC1B4E8,true));w.addView(text(fmt(balance),32,WHITE,true));w.addView(text("Minimum shown: ₹100 • demo only",12,MUTED,false));card(body,w);
        LinearLayout dep=column();dep.addView(text("＋ Demo Deposit",18,WHITE,true));dep.addView(text("Simulates a deposit only.",12,MUTED,false));EditText da=input("Amount (minimum 100)","100");dep.addView(da);gap(dep,8);dep.addView(button("Add demo balance",()->{double n=read(da);if(n<100){toast("Demo minimum deposit is ₹100");return;}balance+=n;refreshWallet();toast("Demo balance updated. No payment taken.");}));card(body,dep);
        LinearLayout wd=column();wd.addView(text("↗ Demo Withdrawal",18,WHITE,true));wd.addView(text("Creates a sample request only.",12,MUTED,false));EditText wa=input("Amount (minimum 100)","100");wd.addView(wa);gap(wd,8);wd.addView(button("Create demo request",()->{double n=read(wa);if(n<100){toast("Demo minimum withdrawal is ₹100");return;}if(n>balance){toast("Not enough demo balance");return;}balance-=n;refreshWallet();toast("Demo request recorded only. No money sent.");}));card(body,wd);notice("Real UPI/bank payments require an approved provider, secure backend, and legal review. This demo does not collect bank details.");}
    void refreshWallet(){showWallet();}
    void showProfile(){base("Profile 👤");LinearLayout p=column();p.addView(text("Account settings preview",14,WHITE,true));p.addView(text("Google / Gmail login",13,MUTED,false));p.addView(text("Facebook login",13,MUTED,false));p.addView(text("Phone number + OTP",13,MUTED,false));gap(p,10);p.addView(button("Demo profile",()->toast("No account is created in this prototype.")));card(body,p);notice("Real sign-in needs configured identity providers and a secure backend.");}
    EditText input(String hint,String val){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setHintTextColor(MUTED);e.setTextColor(WHITE);e.setText(val);e.setInputType(8194);e.setPadding(12,8,12,8);e.setBackground(bg(BG,14,0xFF34405C));return e;}
    double read(EditText e){try{return Double.parseDouble(e.getText().toString());}catch(Exception ex){return 0;}}
    void claim(String name,double n){balance+=n;earned+=n;claimed++;showDashboard();toast("Demo reward added: "+fmt(n)+" — not real money.");}
    void notice(String s){TextView t=text("⚠ "+s,11,0xFFF3D6A0,false);t.setPadding(12,12,12,12);t.setBackground(bg(0xFF2A2115,16,0xFF67502B));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=8;body.addView(t,p);}
    String fmt(double x){return String.format(Locale.US,"₹%.2f",x);}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
